# Transit Ledger — Power BI report source

Five story pages: Welcome, Performance, Cost Pressure, Funding and The Ledger. Hidden support pages: How to read and Monthly fieldnote. The live Power BI service successfully imported the PBIR definition and all model measures are error-free.

## Open the project
Open TransitLedger.pbip in a current Windows Power BI Desktop. Report metadata is bound by path to the included TMDL semantic model. Replace YOUR_SQL_ENDPOINT in model partition M with your own authorized Fabric SQL endpoint and configure OAuth credentials. This is source metadata, not embedded imported rows or credentials. The source CSV snapshots remain in the parent repository data/raw folder. Windows Desktop opening has not been validated from this macOS session.

## Design process
Finding-first wireframe → semantic design tokens → reusable HTML/SVG components → native navigation and filters → model checks and browser interaction review. Serif display text contrasts with sans labels. Coral graphics mark above-plan pressure; darker coral text and active buttons improve small-text contrast. Signed values and status pills supplement colour.

## Controls
Single-select Year is synchronized across the story, saved on 2025. Account redraws the Performance line and filters Ledger. Cost Measure switches dollar/index/actual/budget bars and monthly heatmap together. Funding View changes the large KPI and monthly columns between gap/cash and coverage views. Ledger has searchable accounts and Top N ranked by absolute annual variance. The native monthly sparkline carries real month context into a report-page tooltip; the large SVG is an editorial graphic.

## Scope and limitations
NYCT non-reimbursable operating expenses before non-cash liability adjustments: Actual versus same-year Adopted Budget. Funding: selected dedicated taxes and state/local subsidies, Cash versus source NREIMB accrual category, excluding interagency eliminations. This is not total organizational cash flow, an audited reconciliation or evidence of causation. Annual totals use unrounded values. Static 2023–2025 source snapshot.

## Source structure
TransitLedger.Report: editable PBIR plus registered assets. TransitLedger.SemanticModel: TMDL model. src/Model mirrors the TMDL files. src/StaticResources contains the native JSON theme. dax contains every live measure and per-page files. html-components contains source-backed 2025 render snapshots and tokens.css. Validation results are in validation.json.

## Photography
Zoshua Colah / Unsplash: https://unsplash.com/photos/U7sa3qyocpI (Unsplash License), under a navy overlay. No Gus Bavia assets or code were copied.

## Performance evidence
Performance is one HTML visual plus a small native monthly detail chart, reduced from seven HTML containers. Two recorded edit-mode runs measured the HTML visual at 2521 and 3340 ms, and the native month chart at 1265 and 1304 ms. These are not anonymous end-to-end load-time benchmarks.
